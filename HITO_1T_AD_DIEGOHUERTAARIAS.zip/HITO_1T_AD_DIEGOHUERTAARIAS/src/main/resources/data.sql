CREATE database BOOKWORLD;
USE BOOKWORLD;

-- Tabla Cliente
CREATE TABLE Cliente (
                         ID_cliente INT PRIMARY KEY AUTO_INCREMENT,
                         Nombre VARCHAR(100),
                         Telefono VARCHAR(15),
                         Direccion VARCHAR(255)
);

-- Tabla Producto
CREATE TABLE Producto (
                          ID_Producto INT PRIMARY KEY AUTO_INCREMENT,
                          Nombre VARCHAR(100),
                          Precio DECIMAL(10, 2),
                          Stock INT,
                          Fecha DATE
);

-- Tabla Venta
CREATE TABLE Venta (
                       ID_Venta INT PRIMARY KEY AUTO_INCREMENT,
                       Fecha DATE,
                       Total DECIMAL(10, 2),
                       ID_cliente INT,
                       FOREIGN KEY (ID_cliente) REFERENCES Cliente(ID_cliente)
);

-- Tabla VentaProducto (tabla intermedia entre Venta y Producto)
CREATE TABLE VentaProducto (
                               ID_venta INT,
                               ID_Producto INT,
                               Cantidad INT,
                               Total DECIMAL(10, 2),
                               PRIMARY KEY (ID_venta, ID_Producto),
                               FOREIGN KEY (ID_venta) REFERENCES Venta(ID_Venta),
                               FOREIGN KEY (ID_Producto) REFERENCES Producto(ID_Producto)
);
-- Insert data into Cliente table
INSERT INTO Cliente (Nombre, Telefono, Direccion) VALUES ('Juan Perez', '123456789', 'Calle Falsa 123');
INSERT INTO Cliente (Nombre, Telefono, Direccion) VALUES ('Maria Lopez', '987654321', 'Avenida Siempre Viva 456');
INSERT INTO Cliente (Nombre, Telefono, Direccion) VALUES ('Carlos Sanchez', '555555555', 'Boulevard de los Sueños 789');

-- Insert data into Producto table
INSERT INTO Producto (Nombre, Precio, Stock, Fecha) VALUES ('Producto A', 10.99, 100, '2023-01-01');
INSERT INTO Producto (Nombre, Precio, Stock, Fecha) VALUES ('Producto B', 20.99, 200, '2023-02-01');
INSERT INTO Producto (Nombre, Precio, Stock, Fecha) VALUES ('Producto C', 30.99, 300, '2023-03-01');

-- Insert data into Venta table
INSERT INTO Venta (Fecha, Total, id_cliente) VALUES ('2023-04-01', 100.50, 1);
INSERT INTO Venta (Fecha, Total, id_cliente) VALUES ('2023-05-01', 200.75, 2);
INSERT INTO Venta (Fecha, Total, id_cliente) VALUES ('2023-06-01', 300.25, 3);
USE BOOKWORLD;

-- Insertar más datos en la tabla Cliente
INSERT INTO Cliente (Nombre, Telefono, Direccion) VALUES
                                                      ('Ana Torres', '111222333', 'Calle Luna 456'),
                                                      ('Luis Martinez', '444555666', 'Avenida Sol 789'),
                                                      ('Elena Gomez', '777888999', 'Calle Estrella 101');

-- Insertar más datos en la tabla Producto
INSERT INTO Producto (Nombre, Precio, Stock, Fecha) VALUES
                                                        ('Libro D', 24.99, 120, '2024-04-01'),
                                                        ('Libro E', 34.99, 60, '2024-05-01'),
                                                        ('Libro F', 44.99, 80, '2024-06-01');

-- Insertar más datos en la tabla Venta
INSERT INTO Venta (Fecha, Total, ID_cliente) VALUES
                                                 ('2024-11-04', 49.98, 4),
                                                 ('2024-11-05', 34.99, 5),
                                                 ('2024-11-06', 44.99, 6);

-- Insertar más datos en la tabla VentaProducto
INSERT INTO ventaproducto (ID_venta, ID_Producto, Cantidad, Total) VALUES
                                                                       (7, 4, 2, 49.98),
                                                                       (8, 5, 1, 34.99),
                                                                       (9, 6, 1, 44.99);